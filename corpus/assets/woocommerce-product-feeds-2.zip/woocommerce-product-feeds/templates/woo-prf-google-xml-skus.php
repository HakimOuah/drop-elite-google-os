                        <skus>
{skus}
                        </skus>