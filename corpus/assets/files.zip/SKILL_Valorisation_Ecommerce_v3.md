# SKILL — Valorisation de boutique e-commerce (Kraken x Dot Market)
## Version 3.0 — Terrain LTY confirmé + leviers d'optimisation + structure charges corrigée

## Déclencheur
Utilise ce skill quand l'utilisateur veut :
- Estimer / valoriser une boutique e-commerce
- Remplir ou analyser un P&L de boutique Shopify
- Préparer un dossier de cession / vente de boutique
- Identifier les leviers pour améliorer la valorisation avant vente
- Créer un P&L rapide à partir de données partielles

---

## ⚠️ RÈGLE FONDAMENTALE — TOUT EN HORS TAXE (HT)

**Toutes les données doivent être converties en HT avant tout calcul de valorisation.**

C'est l'erreur la plus fréquente et la plus grave : présenter un CA TTC gonfle artificiellement la base de calcul et donc la valorisation.

### Règles de conversion

| Source de données | Traitement |
|---|---|
| CA Shopify affiché | Vérifier si TTC → diviser par 1.20 (FR/UK) ou 1.21 (ES) |
| Export comptable | Toujours demander la version HT |
| Dépenses pub (Google/Meta) | Généralement HT sur factures — vérifier |
| Apps Shopify | Facturées HT (entreprise B2B) |
| COGS fournisseur Chine | Hors TVA française — déjà HT |
| Frais bancaires / Shopify Payments | Vérifier si TTC selon plan |

### Comment vérifier dans Shopify
- Analytics → Finances → Vue "HT" (exclure taxes)
- Export Orders → colonne "Subtotal" = HT, "Total" = TTC
- Si doute : CA affiché / 1.20 = approximation FR valide

### Impact concret
> CA TTC 120 000€ → CA HT 100 000€
> Sur une marge nette de 20% : bénéfice TTC apparent = 24 000€ vs bénéfice HT réel = 20 000€
> À x18 : différence de valorisation = **72 000€**. L'erreur coûte cher.

### Ligne bénéfice TTC — usage et limites
Il est utile d'ajouter une ligne "Bénéfice net TTC" dans le P&L (CA TTC net − toutes charges HT) pour deux raisons :
- **Pilotage cashflow** : reflète l'argent réellement disponible sur le compte avant reversement TVA
- **Business sans TVA reversée** : permet de voir le profit opérationnel réel dans cette configuration

⚠️ Cette ligne NE DOIT PAS être utilisée comme base de valorisation. La valorisation reste toujours sur le bénéfice HT.

---

## Philosophie de valorisation (Kevin Jourdan / Dot Market)

> "Le canal numéro 1, c'est le profit. C'est le profit qui va faire la valorisation."
> "Un bon business à posséder n'est pas forcément un bon business à vendre."

### Principe fondamental
La valorisation = **Profit net mensuel HT × Multiplicateur**
Le multiplicateur dépend de tout le reste (qualité, stabilité, trafic, documentation).

### Méthode unique retenue : M1 — Multiple du bénéfice net HT
**Il n'existe qu'une seule méthode fiable pour les boutiques e-com < 30 000€/mois de profit HT : le multiple du bénéfice net HT.**

La méthode "multiple du CA HT" (0.4x–0.8x) est inapplicable pour ce type d'actif car :
- Elle ne tient pas compte de la structure de coûts (deux boutiques au même CA peuvent valoir 3x différemment)
- Les acheteurs ne raisonnent pas en multiple de CA pour ce segment
- Elle peut surévaluer massivement un business peu rentable

> Exemple : CA HT annualisé 140 000€ × 0.7x = 98 000€ apparents. Mais si le bénéfice net est 800€/mois → valo réelle 12 000–15 000€. L'écart est de 6x. Ne jamais utiliser le multiple CA.

### Vendre au bon moment
- Vendre quand le business est **en croissance**, pas quand on est acculé
- 90% des vendeurs arrivent chez Dot Market en mode "je dois vendre maintenant" → mauvaise position
- La meilleure vente se prépare **12 à 24 mois à l'avance**
- Ne jamais réduire les ads ou arrêter d'acheter du stock pendant la mise en vente
- **Attendre la stabilisation post-refonte** : 3–4 mois de CA stable après un changement majeur

---

## Multiplicateurs par tranche de profit (données Kevin Jourdan 2024)

| Profit mensuel HT | Profil acheteur | Multiple |
|---|---|---|
| < 1 000 €/mois | Side business / personne physique | x12 – x15 |
| 1 000 – 5 000 €/mois | Small investor / repreneur actif | x15 – x18 |
| 5 000 – 10 000 €/mois | Business établi / gérant actif | x18 – x24 |
| 10 000 – 30 000 €/mois | Vraie société / gérant temps plein | x24 – x36 |
| > 30 000 €/mois | Fonds / industriels / M&A | x24 – x60 |

**Marché US (Flippa, Empire Flippers)** : multiples 20-40% plus élevés qu'en France pour boutiques en anglais.

---

## Structure des charges — distinction critique

**Ne jamais regrouper toutes les charges dans une seule ligne "charges fixes".** La distinction est essentielle pour l'acheteur et pour l'analyse des leviers.

### Charges fixes incompressibles (SaaS — indépendantes du CA)
Ce sont les seuls vrais coûts plancher du business. Ils existent même si le CA tombe à zéro.
- Shopify + apps
- Klaviyo / Brevo (emailing)
- Autres outils SaaS (avis clients, tracking, etc.)
- OVH / hébergement

> Exemple terrain : ~700€/mois de fixes incompressibles pour une boutique à 12 000€ CA/mois HT.

### Charges variables de structure (proportionnelles au volume)
- **Stripe / PayPal** : % du CA — ⚠️ **TOUJOURS vérifier le taux réel sur les relevés Shopify**. Le taux réel Shopify Payments est 1.7–2.5% selon le plan, pas 3%. L'erreur de 0.5–1% sur un CA de 12 000€ représente 60–120€/mois de biais.
- **SAV** : proportionnel au volume de commandes
- **Équipe / Media Buyer** : souvent % des dépenses pub
- **Frais bancaires divers**

---

## Les leviers de valeur — par ordre d'impact

| Levier | Signal positif | Impact multiplicateur |
|---|---|---|
| **SEO organique** | > 30% du CA via organique | +0.3x |
| **Email marketing** | > 15% CA via email, liste > 5k contacts | +0.2x |
| **Récurrence d'achat** | Consommables, box, abonnement | +0.5x à +1.0x |
| **Google Ads** | ROAS stable > 3.5x, historique clean | Valeur pilotable pour acheteur |
| **Facebook Ads** | < 50% du CA via FB | Si > 50% : -0.5x (risque ban) |
| **Marque déposée** | INPI / USPTO | Prime de sécurité juridique |
| **Fournisseur** | Multi-sources, contrats signés | Unique sans contrat = -0.2x |
| **Ancienneté** | > 24 mois de data | < 12 mois = refus Dot Market |
| **Temps gestionnaire** | < 10h/semaine | Plus automatisé = mieux |
| **Avis clients** | TrustPilot > 4★ | < 3.5★ = dévalue fortement |
| **TVA à jour** | Comptabilité propre | Non payée = rédhibitoire |

---

## Leviers d'optimisation des marges — terrain confirmé

Cette section est issue du travail concret sur Le Temple Yogi (LTY). Ces leviers s'appliquent à la majorité des boutiques e-com drop/print.

**Règle d'or** : chaque point de % récupéré sur le CA HT = ~CA_HT_mensuel × 0.01 € de bénéfice supplémentaire par mois, multiplié par x15 à x18 sur la valorisation.

### 🔴 Priorité haute — impact direct et rapide

**1. COGS — Vérifier la surfacturation fournisseur**
- Benchmark sain : 27–32% du CA HT. Au-delà de 33% = alerte.
- Les agents logistiques gonflent fréquemment les dimensions/poids → surfacturation shipping
- Action : demander photos + vidéos de l'emballage réel, comparer poids facturé vs réel
- Mettre un process de vérification hebdomadaire des factures fournisseur
- Potentiel : +300 à +700€/mois si COGS redescend de 35% à 28%

**2. Google Ads — Couper ce qui perd de l'argent**
- ROAS minimum viable : 2.8x (CA HT ÷ spend). En dessous = perte nette.
- Ne jamais laisser tourner des campagnes sous ce seuil "pour avoir du volume"
- Concentrer le budget sur les campagnes DSA et les marchés qui performent
- Potentiel : +200 à +600€/mois si ROAS remonte à 3.5x+

### 🟠 Priorité moyenne — gains certains mais moins immédiats

**3. Frais bancaires — Vérifier le vrai taux Stripe**
- Ne jamais utiliser le 3% par défaut sans vérifier les relevés réels
- Shopify Payments : 1.7–2.5% selon plan. PayPal : ~3.4% mais souvent faible volume.
- Potentiel : +100 à +200€/mois si taux réel ~2%

**4. Email marketing — Canal sous-exploité**
- La plupart des boutiques sont à 5–10% du CA via email. Objectif : 15–25%.
- Klaviyo / Brevo sont déjà payés → coût marginal quasi nul pour activer les flows
- Flows prioritaires : welcome series (J+1, J+3, J+7), post-achat upsell, winback 90j
- Potentiel : +500 à +1 500€/mois à coût quasi nul

**5. Audit apps — Éliminer les doublons**
- Vérifier si deux outils font la même chose (ex : deux outils emailing actifs)
- Apps Shopify non auditées = 300–600€/mois gaspillés en moyenne
- Potentiel : +100 à +300€/mois d'économie directe

### 🟡 Priorité long terme — impact fort mais délai 6–12 mois

**6. SEO — Reconstruire le trafic organique**
- Le SEO chute généralement après une longue période sans travail éditorial
- Chaque article blog réédité avec IA + brief SEO = trafic gratuit perpétuel
- Schema markup produit, maillage interne par univers thématique
- Potentiel : +400 à +1 200€/mois à 12 mois

**7. AOV — Augmenter le panier moyen**
- Bundles thématiques, cross-sell en page panier, upsell post-achat
- Les produits à forte marge doivent être mis en avant (pas les best-sellers bas de gamme)
- Potentiel : +200 à +600€/mois si AOV +15%

---

## Critères éliminatoires (refus immédiat Dot Market)

Ces critères bloquent toute vente sérieuse :
1. **Ancienneté < 12 mois** — données insuffisantes, pas de saisonnalité visible
2. **TVA non payée** — rédhibitoire, aucun acheteur institutionnel ne passera
3. **Aucune rentabilité documentée** — pas de base de calcul
4. **Domaine expiré utilisé comme raccourci SEO** — risque légal latent
5. **Dépendance 100% ads sans aucun SEO** — le business "s'éteint" sans pub
6. **Mauvais avis TrustPilot (< 3.5★)** — signal de problème produit/SAV

---

## Les 3 documents indispensables pour la vente (Kevin Jourdan)

**"C'est le combo le plus sous-estimé. Ces 3 documents font souvent la différence entre une vente et pas de vente."**

### 1. Le P&L (ce fichier) — TOUT EN HT
- 12 mois minimum, 24 mois idéal
- Revenus HT nets, COGS HT, charges séparées (fixes vs variables), bénéfice net HT
- Ligne bénéfice TTC en information complémentaire (cashflow opérationnel)
- Répartition trafic par canal (SEO / Email / Google / FB) avec % du CA attribué

### 2. Le Playbook opérationnel
- Comment fonctionne le business au quotidien ?
- Traitement des commandes (Shopify → fournisseur → client)
- Gestion du SAV (templates de réponse, outil utilisé)
- Gestion des campagnes pub (structure, budgets, créatifs)
- Contacts fournisseurs, prestataires, logisticien
- Processus qualité commande (vérification factures fournisseur)

### 3. Le document "Next Actions"
- Liste des 10–20 actions identifiées pour développer le business
- Ex : "Activer welcome series Klaviyo", "Créer des bundles produits", "Ouvrir marché UK"
- **Cela aide l'acheteur à se projeter → peut faire monter le prix de 10–20%**

---

## SDE — Seller Discretionary Earnings (subtilité importante)

Pour les petits business où le gérant travaille lui-même dans l'activité :
- Le salaire du dirigeant peut être **retraité** (retiré des charges)
- Car l'acheteur se paiera pareillement depuis le cashflow du business
- **SDE = Bénéfice net HT + Salaire dirigeant retraité**
- La valorisation SDE est plus pertinente pour les business < 5 000€/mois de profit HT

> Exemple : Business fait 1 500€ HT de "bénéfice net" mais le gérant se paye 2 000€/mois.
> SDE = 1 500 + 2 000 = 3 500€/mois → base de valorisation réelle.

---

## Structures de transaction (au-delà du prix)

La vente d'un business ne se résume pas au prix. Kevin insiste : il y a 4 variables à négocier :

1. **Le prix** — fourchette basse / haute (pas un prix fixe)
2. **L'acompte** — typiquement 50–70% à la signature
3. **Le crédit vendeur** — solde payé en mensualités sur le cashflow du business
4. **L'accompagnement** — durée de coaching post-vente (2 à 3 mois recommandé)

> Exemple win-win : acheteur propose 15 000€ comptant vs 20 000€ avec 3 mois d'accompagnement.
> Le vendeur peut préférer l'option 15 000€ s'il veut passer à autre chose rapidement.

---

## Données essentielles pour un P&L complet

### Obligatoires — TOUTES EN HT
```
✅ CA mensuel HT sur 12 mois minimum (TTC ÷ 1.20 si données Shopify brutes)
✅ Remboursements/refunds mensuels (à déduire du CA TTC avant conversion HT)
✅ COGS — coût des produits achetés HT (factures fournisseur)
   → Benchmark terrain confirmé : 27–32% du CA HT pour du drop classique
   → Au-delà de 33% : alerte surfacturation à investiguer
✅ Google Ads HT par mois (export depuis Google Ads en EUR)
✅ Facebook/Meta Ads par mois (export CSV Meta Business Manager par période)
   → ⚠️ Toujours exporter par mois, pas en agrégé — les données agrégées masquent les mois zéro
✅ Charges fixes incompressibles (Shopify, SaaS emailing, autres outils)
✅ Charges variables de structure (Stripe réel, SAV, équipe MB, frais bancaires)
```

### Reconstruction données Facebook manquantes
Quand les données FB sont incomplètes par mois :
1. Exporter le CSV Meta Business Manager sur la période agrégée (ex : Sep–Déc)
2. Identifier les mois connus dans la compta
3. Déduire les mois inconnus : (Total agrégé − mois connus) ÷ nombre de mois restants
4. Signaler clairement les mois estimés vs confirmés dans le P&L

### Très utiles (impact fort sur multiplicateur)
```
⭐ Répartition trafic GA4 (% CA attribué par canal : SEO / Paid / Email / Direct)
⭐ Taille liste email + taux d'ouverture (Klaviyo / Brevo export)
⭐ Domain Rating + trafic organique mensuel (Semrush / Ahrefs)
⭐ AOV HT et taux de conversion (GA4)
⭐ Temps gestionnaire hebdomadaire (h/semaine)
```

### Différenciants (souvent oubliés)
```
💡 Taux Stripe réel (relevés Shopify Payments — ne jamais estimer à 3% sans vérifier)
💡 Historique publicitaire (bans ? suspensions ? ancienneté compte Google/Meta)
💡 Contrats fournisseurs (exclusivité, tarif négocié, ancienneté relation)
💡 Marque déposée INPI / USPTO
💡 Frais de conversion devises (2% sur dépenses pub USD depuis compte EUR)
💡 Doublons d'outils (ex : deux outils emailing actifs — économie directe à identifier)
```

---

## Frais cachés fréquemment oubliés dans le P&L

Ces éléments peuvent représenter des milliers d'euros/mois de biais :

1. **Taux Stripe surestimé** : estimer 3% quand le réel est 1.8% = 120€/mois de biais sur 12 000€ CA
2. **Surfacturation COGS** : dimensions/poids gonflés par l'agent → vérifier mensuellement
3. **Doublons SaaS** : deux outils emailing, deux outils avis, apps Shopify oubliées
4. **Conversion devises pub** : dépenses USD prélevées sur compte EUR = 1.5–2% de frais cachés
5. **Données pub manquantes** : mois à 0€ par manque de données vs mois réellement à 0€
6. **Remboursements non appliqués** : le fournisseur dit "remboursé" mais ne l'a pas fait

---

## Marchés de revente (France + International)

### France (marchés vérifiés)
- **Dot Market** (dotmarket.eu) — leader FR, accompagnement complet, analyse digitale + financière
- **Session PME / Story.be / Dealing Room** — analyse financière uniquement, pas digitale
- **Le Bon Coin / Fusac / Alvo** — petites annonces brutes, risque élevé
- **Groupes Facebook** — non filtré, risque maximal

### International (pour boutiques en anglais)
- **Flippa** (flippa.com) — leader mondial petits/moyens business digitaux
- **Empire Flippers** — sélectif, accompagnement premium, multiples plus élevés
- **Acquire.com** — SaaS et e-com établis
- **FE International** — gros deals > 500K$

> Si la boutique vend en anglais → toujours évaluer le marché US en parallèle. Multiples 20–40% supérieurs.

---

## Structure du template Excel (4 onglets — v3)

### Onglet 1 — P&L Mensuel HT
- Mois 1 → Mois N | Total | Moyenne mensuelle
- **Toutes les cellules de revenus = HT obligatoirement**
- Section 1 : CA (TTC brut → remboursements → CA net TTC → CA HT)
- Section 2 : COGS + % du CA HT + marge brute
- Section 3 : Pub (Google + Facebook séparés, ROAS calculé, total pub, marge après pub)
- Section 4A : Charges fixes incompressibles (SaaS uniquement)
- Section 4B : Charges variables de structure (Stripe réel, SAV, MB, frais bancaires)
- Section 5 : Bénéfice net HT + marge nette % + ligne bénéfice TTC (info cashflow)
- Section 6 : Récapitulatif % CA par grande catégorie

### Onglet 2 — Valorisation
- Base : bénéfice net HT moyen mensuel (lien automatique depuis P&L)
- Multiplicateurs x15 / x18 / x24 (modifiables en bleu)
- **Méthode unique M1** : bénéfice HT × multiplicateur (méthode CA supprimée)
- Simulateur : cellule bénéfice cible modifiable → valo post-optimisation
- Critères Dot Market avec alertes couleur
- Structure de transaction (acompte / crédit vendeur / accompagnement)

### Onglet 3 — Leviers optimisation
- 8 leviers classés par priorité (🔴 court terme / 🟠 moyen / 🟡 long terme)
- Pour chaque levier : situation actuelle / impact €/mois / gain valo (x15) / action concrète
- Ligne synthèse : potentiel total si 50% des leviers activés

### Onglet 4 — Hypothèses
- Paramètres de base (TVA, taux Stripe, taux de change)
- Répartition trafic GA4 par canal avec CA attribué
- Table des multiplicateurs Kevin Jourdan 2024
- Grille qualité & signaux avec impact sur multiplicateur

---

## Comportement si données partielles

Ne jamais inventer. Toujours :
1. **Vérifier et convertir en HT** avant tout calcul
2. Remplir les cellules connues avec la source explicite
3. Signaler clairement les estimations vs les données confirmées
4. Lister explicitement ce qui manque ET son impact estimé
5. Donner une fourchette conservatrice

**Template de réponse partielle :**
> "Sur la base du CA HT et des dépenses pub fournies, la valorisation est entre X€ et Y€.
> Attention : j'ai appliqué une conversion HT (÷1.20) sur le CA fourni — à confirmer.
> Les données FB de Sep–Nov sont estimées (total trimestriel ÷ 3) — à confirmer avec un export mensuel.
> Il manque : (1) le taux Stripe réel — si 2% au lieu de 3%, +80€/mois de bénéfice ;
> (2) la répartition trafic GA4 — si SEO > 30% ça monterait le multiple de x15 à x18 ;
> (3) le taux réel COGS — si le fournisseur surfacture le shipping, potentiel +300€/mois."

---

## Workflow de création du fichier

```python
# 1. openpyxl uniquement (jamais pandas pour les formules)
# 2. Conventions couleurs :
#    Bleu (FF0070C0) + fond jaune (FFFFFF00) → saisie manuelle
#    Vert (FF00B050)                          → formule / lien inter-feuille
#    Noir (FF000000)                          → formule calculée
#    Gris italique (FF595959)                 → ligne informative (ex : bénéfice TTC)
# 3. Toujours des formules Excel, jamais de valeurs hardcodées calculées en Python
# 4. Séparer charges fixes (4A) et charges variables (4B) — ne jamais fusionner
# 5. Lancer scripts/recalc.py après génération
# 6. Vérifier zéro erreur (#REF!, #DIV/0!, etc.)
# 7. Libeller les colonnes "HT" explicitement partout
```

---

## Checklist de livraison

- [ ] Toutes les données vérifiées / converties en HT
- [ ] Sources des données explicites (compta / CSV / GA4 / estimé)
- [ ] Charges fixes (4A) et variables (4B) séparées
- [ ] Taux Stripe réel vérifié (pas estimé à 3%)
- [ ] Données Facebook confirmées mois par mois (pas de zéros sans explication)
- [ ] 4 onglets (P&L, Valorisation, Leviers, Hypothèses)
- [ ] Méthode M1 uniquement si profit < 5 000€/mois HT
- [ ] Multiplicateurs visibles et modifiables (cellules bleues)
- [ ] Simulateur post-optimisation présent
- [ ] Critères Dot Market vérifiés avec alertes couleur
- [ ] Fourchette basse / cible / haute visibles
- [ ] Ligne bénéfice TTC présente (info cashflow, pas base valo)
- [ ] Leviers d'optimisation chiffrés et priorisés
- [ ] Zéro erreur de formule
